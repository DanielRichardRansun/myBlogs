-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 18 Agu 2024 pada 19.02
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myblogs`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `categories`
--

CREATE TABLE `categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `categories`
--

INSERT INTO `categories` (`id`, `title`, `description`) VALUES
(7, 'Uncategorized', 'This is Uncategorized post.'),
(8, 'Art ', 'Art is the expression or application of human creative skill and imagination, typically in a visual form such as painting or sculpture, producing works to be appreciated primarily for their beauty or emotional power.'),
(9, 'Wild Life', 'Wildlife refers to undomesticated animal species, but has come to include all organisms that grow or live wild in an area without being introduced by humans.'),
(10, 'Travel', 'Travel is go from one place to another, typically over a distance of some length.'),
(11, 'Science &#38; Technology', 'Science is the study of the natural world by collecting data through a systematic process called the scientific method.And technology is where we apply science to create devices that can solve problems and do tasks. '),
(12, 'Food', 'Food is any nutritious substance that people or animals eat or drink or that plants absorb in order to maintain life and growth.'),
(13, 'Music ', 'Music is vocal or instrumental sounds (or both) combined in such a way as to produce beauty of form, harmony, and expression of emotion.'),
(16, 'Health &#38; Wellness', 'Health is the state of complete physical, mental, and social well-being and not merely the absence of disease, or infirmity. Wellness is an active process through which people become aware of, and make choices toward, a more successful existence.'),
(17, 'History', 'a record or narrative description of past events · noun. all that is remembered of the past as preserved in writing; a body of knowledge.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `category_id` int(11) UNSIGNED DEFAULT NULL,
  `author_id` int(11) UNSIGNED NOT NULL,
  `is_featured` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `thumbnail`, `date_time`, `category_id`, `author_id`, `is_featured`) VALUES
(7, 'Menavigasi Dunia Teknologi Modern: Panduan Komprehensif', 'Di era digital yang serba cepat ini, memahami teknologi menjadi sangat penting. Teknologi telah menjadi bagian integral dari kehidupan sehari-hari, mempengaruhi cara kita bekerja, berkomunikasi, dan bersosialisasi. Setiap hari, kita dihadapkan pada inovasi baru yang menawarkan berbagai peluang sekaligus tantangan. Dengan begitu banyak perkembangan yang terjadi, penting untuk memiliki panduan yang komprehensif untuk menavigasi dunia teknologi modern.\r\n\r\nDari kemajuan dalam kecerdasan buatan (AI) hingga tren terbaru dalam keamanan siber, blog ini membahas berbagai aspek penting dari teknologi. Kemajuan AI, misalnya, telah membawa perubahan signifikan dalam berbagai sektor, dari kesehatan hingga pendidikan. Sementara itu, keamanan siber menjadi semakin krusial dengan meningkatnya ancaman dan serangan yang mengincar data pribadi dan institusi.\r\n\r\nBlog ini tidak hanya fokus pada teknologi itu sendiri, tetapi juga mempertimbangkan dampak dan pertimbangan etis yang menyertainya. Bagaimana inovasi teknologi memengaruhi kehidupan kita sehari-hari dan apa saja tantangan etis yang muncul? Dengan memahami implikasi ini, kita bisa membuat keputusan yang lebih baik tentang cara kita menggunakan teknologi.', '1723742273blog15.jpg', '2024-08-15 17:17:53', 11, 3, 0),
(8, 'Seni Minimalisme: Menyederhanakan Hidup di Dunia yang Kacau', 'Minimalisme bukan hanya tren desain; ini adalah pilihan gaya hidup yang dapat membawa kedamaian dan kepuasan lebih dalam kehidupan sehari-hari. Dalam blog ini, kami mengeksplorasi prinsip-prinsip minimalisme dan bagaimana pendekatan ini dapat diterapkan tidak hanya dalam desain interior tetapi juga dalam berbagai aspek kehidupan Anda. Temukan cara-cara untuk merapikan ruang dan pikiran Anda, menciptakan lingkungan yang lebih teratur dan menyenangkan.\r\n\r\nKami membagikan tips praktis untuk merangkul kesederhanaan, mulai dari menyusun dan mengorganisir barang-barang di rumah hingga mengelola waktu dan prioritas Anda. Blog ini menawarkan panduan langkah-demi-langkah untuk membantu Anda mengurangi kekacauan dan fokus pada apa yang benar-benar penting, menciptakan ruang untuk kreativitas, ketenangan, dan kebahagiaan.\r\n\r\nDengan memahami dan menerapkan prinsip minimalisme, Anda dapat mencapai kehidupan yang lebih memuaskan dan bermakna. Blog ini bertujuan untuk menginspirasi Anda untuk mengevaluasi dan menyederhanakan berbagai aspek hidup Anda, sehingga Anda dapat menikmati manfaat dari gaya hidup yang lebih terfokus dan bebas dari beban yang tidak perlu.', '1723742353blog30.jpg', '2024-08-15 17:19:13', 8, 3, 0),
(9, 'Mengurai Makna Seni dalam Kehidupan', 'Seni adalah cerminan jiwa manusia, sebuah medium yang menyentuh emosi dan mengekspresikan gagasan yang sering kali sulit diungkapkan dengan kata-kata. Dalam blog ini, kami menggali kedalaman berbagai bentuk seni, mulai dari lukisan, patung, dan instalasi hingga seni pertunjukan dan digital. Kami menyajikan analisis mendalam tentang karya-karya seni yang mencolok dan menjelajahi bagaimana setiap bentuk seni menyampaikan pesan dan perasaan yang unik.\r\n\r\nKami juga mengeksplorasi dampak seni terhadap kita secara psikologis dan budaya, mengungkap bagaimana seni dapat mempengaruhi suasana hati, meningkatkan kesejahteraan mental, dan memperkaya pengalaman budaya. Temukan bagaimana seni tidak hanya berfungsi sebagai sarana ekspresi tetapi juga sebagai alat untuk refleksi pribadi dan pemahaman budaya yang lebih dalam.\r\n\r\nMelalui penelusuran ini, kami bertujuan untuk menginspirasi Anda untuk menghargai dan terlibat dengan seni dalam kehidupan sehari-hari. Blog ini menawarkan wawasan tentang bagaimana seni berperan dalam membentuk identitas dan masyarakat, serta bagaimana kita bisa menemukan makna dan inspirasi dalam karya seni yang kita temui.', '1723743000blog72.jpg', '2024-08-15 17:30:00', 8, 24, 0),
(10, 'Keajaiban Alam: Menyaksikan Kehidupan Liar', 'Kehidupan liar adalah sumber inspirasi yang tak terbatas, menawarkan pandangan mendalam tentang keanekaragaman hayati dan keajaiban dunia fauna. Dalam blog ini, kami mengeksplorasi berbagai aspek kehidupan hewan, mulai dari perilaku unik yang menarik hingga adaptasi luar biasa yang membantu mereka bertahan di lingkungan alam mereka. Temukan kisah-kisah menarik dan informasi mendalam tentang spesies-spesies yang mungkin belum Anda ketahui sebelumnya.\r\n\r\nKami juga membahas pentingnya konservasi alam dan upaya yang dilakukan untuk melindungi habitat dan spesies yang terancam punah. Blog ini menyoroti berbagai inisiatif dan proyek konservasi yang bertujuan untuk menjaga keseimbangan ekosistem dan memastikan bahwa keanekaragaman hayati tetap terjaga untuk generasi mendatang. Dengan memahami tantangan yang dihadapi oleh kehidupan liar, kita bisa lebih menghargai dan mendukung upaya-upaya pelestarian yang penting.\r\n\r\nMelalui penjelajahan mendalam ini, kami berharap dapat meningkatkan kesadaran tentang keindahan dan kerentanannya dunia fauna, serta menginspirasi pembaca untuk turut berperan dalam melindungi keanekaragaman hayati. Temukan keajaiban dan keunikan dunia hewan melalui kisah-kisah yang penuh warna dan informasi yang bermanfaat, dan jadilah bagian dari gerakan untuk menjaga kelestarian alam.', '1723743024blog3.jpg', '2024-08-15 17:30:24', 9, 24, 0),
(11, 'Jelajah Dunia: Mengungkap Pesona Destinasi', 'Bepergian adalah jendela menuju dunia baru, membuka kesempatan untuk mengeksplorasi tempat-tempat eksotis dan merasakan keanekaragaman budaya yang ada di seluruh penjuru bumi. Dalam blog ini, kami menawarkan panduan perjalanan yang mendalam, menyoroti destinasi-destinasi yang menakjubkan, serta budaya lokal yang unik dan menarik. Temukan informasi berharga tentang lokasi-lokasi tersembunyi dan pengalaman autentik yang bisa memperkaya petualangan Anda.\r\n\r\nKami membagikan tips dan rekomendasi tentang tempat-tempat yang wajib dikunjungi, aktivitas yang tidak boleh terlewatkan, serta kuliner lokal yang perlu dicoba. Dengan ulasan dan panduan yang detail, blog ini bertujuan untuk memudahkan Anda merencanakan perjalanan yang tak terlupakan, memberikan wawasan tentang apa yang dapat diharapkan, dan bagaimana merasakan esensi dari setiap destinasi.\r\n\r\nMelalui cerita dan pengalaman yang kami sajikan, kami berharap dapat menginspirasi Anda untuk memulai petualangan baru dan menjelajahi dunia dengan cara yang segar dan penuh rasa ingin tahu. Temukan ide-ide perjalanan yang menyenangkan dan jadikan setiap perjalanan Anda sebagai pengalaman yang memperkaya hidup dan memperluas wawasan Anda tentang dunia.', '1723743089blog8.jpg', '2024-08-15 17:31:29', 10, 28, 0),
(12, 'Inovasi dan Ilmu: Menembus Batasan Pengetahuan', 'Teknologi dan ilmu pengetahuan terus berkembang pesat, secara signifikan mengubah cara kita hidup dan berinteraksi dengan dunia. Dalam blog ini, kami menyajikan penemuan terbaru dan tren teknologi yang sedang berkembang, dari inovasi dalam kecerdasan buatan hingga terobosan dalam bidang bioteknologi. Temukan bagaimana kemajuan ini tidak hanya menciptakan peluang baru tetapi juga membawa tantangan yang perlu kita hadapi.\r\n\r\nKami juga membahas dampak dari teknologi baru terhadap masa depan manusia, termasuk perubahan dalam cara kita bekerja, berkomunikasi, dan berinteraksi dengan lingkungan sekitar. Dengan menjelajahi berbagai teknologi mutakhir dan teori ilmiah yang sedang dikembangkan, blog ini memberikan wawasan tentang bagaimana teknologi akan membentuk kehidupan kita di tahun-tahun mendatang.\r\n\r\nMelalui analisis mendalam dan ulasan terkini, blog ini bertujuan untuk membantu pembaca memahami implikasi dari inovasi teknologi dan ilmiah, serta bagaimana kita bisa mempersiapkan diri untuk masa depan yang terus berubah. Bergabunglah dengan kami dalam penjelajahan ini dan temukan bagaimana ilmu pengetahuan dan teknologi dapat mempengaruhi dunia kita dengan cara yang menarik dan transformatif.', '1723743120blog17.jpg', '2024-08-15 17:32:00', 11, 28, 0),
(13, 'Kelezatan dalam Setiap Gigitan: Dunia Kuliner', 'Makanan lebih dari sekadar kebutuhan; ia adalah seni dan budaya yang menyatukan orang-orang di seluruh dunia. Dalam blog ini, kami mengeksplorasi berbagai masakan dari seluruh penjuru dunia, menyajikan ulasan mendalam tentang resep-resep khas, bahan-bahan unik, dan teknik memasak yang membentuk hidangan yang kita nikmati sehari-hari. Temukan bagaimana setiap hidangan tidak hanya memuaskan selera tetapi juga mencerminkan tradisi dan sejarah budaya yang kaya.\r\n\r\nKami juga membahas cerita menarik di balik setiap hidangan, mulai dari asal-usul resep hingga evolusi kuliner yang terjadi seiring waktu. Dengan menggali latar belakang historis dan budaya dari berbagai masakan, blog ini memberikan wawasan tentang bagaimana makanan berfungsi sebagai jembatan antara masa lalu dan masa kini, serta bagaimana ia berperan dalam kehidupan sehari-hari masyarakat di berbagai belahan dunia.\r\n\r\nMelalui penjelajahan ini, kami bertujuan untuk merayakan kekayaan kuliner global dan mendorong pembaca untuk mengeksplorasi dan mencoba masakan baru. Blog ini mengajak Anda untuk lebih memahami dan menghargai seni memasak sebagai bagian penting dari warisan budaya manusia, serta untuk merasakan kelezatan dan keunikan dari setiap hidangan yang diciptakan.', '1723743162blog13.jpg', '2024-08-15 17:32:42', 12, 26, 0),
(14, 'Melodi Jiwa: Menelusuri Irama dan Lirik', 'Musik adalah bahasa universal yang menyatukan kita semua, melampaui batas-batas budaya dan bahasa untuk menyentuh hati dan jiwa. Dalam blog ini, kami menganalisis berbagai genre musik, dari klasik hingga kontemporer, serta artis-artis yang telah meninggalkan jejak mendalam dalam dunia musik. Kami juga mengeksplorasi lirik-lirik yang menginspirasi, yang tidak hanya meresonansi dengan pendengar tetapi juga sering mencerminkan perasaan dan pengalaman manusia.\r\n\r\nBlog ini mengungkap bagaimana musik mempengaruhi emosi kita dan memainkan peran penting dalam kehidupan sehari-hari. Kami membahas dampak psikologis dari berbagai jenis musik, serta bagaimana musik dapat memengaruhi suasana hati, memotivasi kita, dan memberikan pelarian dari stres. Temukan bagaimana melodi, harmoni, dan ritme dapat membentuk pengalaman kita dan menciptakan koneksi emosional yang mendalam.\r\n\r\nMelalui penelusuran mendalam ini, kami bertujuan untuk menunjukkan kekuatan musik dalam kehidupan kita dan bagaimana kita dapat memanfaatkan pengaruhnya untuk meningkatkan kesejahteraan pribadi. Blog ini mengajak Anda untuk menyelami kekayaan dunia musik dan mengapresiasi bagaimana seni ini dapat memperkaya hidup kita dalam berbagai cara.', '1723743192blog38.jpg', '2024-08-15 17:33:12', 13, 26, 0),
(15, 'Menguak Misteri Satwa Langka', 'Dunia hewan menyimpan banyak rahasia yang sering kali tersembunyi dari pandangan kita, terutama bagi satwa-satwa yang terancam punah. Blog ini mengungkap kisah-kisah menarik di balik hewan-hewan langka, menjelaskan habitat alami mereka, dan mengeksplorasi tantangan yang mereka hadapi akibat aktivitas manusia dan perubahan lingkungan. Kami membahas bagaimana spesies-spesies ini beradaptasi dalam lingkungan mereka dan pentingnya mereka dalam ekosistem global.\r\n\r\nDalam blog ini, Anda akan menemukan informasi mendalam tentang berbagai upaya pelestarian yang dilakukan untuk menyelamatkan satwa-satwa ini dari kepunahan. Kami menyoroti inisiatif-inisiatif yang dicanangkan oleh organisasi konservasi, penelitian ilmiah, dan kolaborasi internasional yang berfokus pada perlindungan dan pemulihan spesies langka. Dengan memahami upaya-upaya ini, kita bisa lebih menghargai kerja keras yang diperlukan untuk melestarikan keanekaragaman hayati.\r\n\r\nMelalui penjelajahan ini, kami bertujuan untuk meningkatkan kesadaran tentang pentingnya melindungi spesies langka dan mendorong tindakan proaktif dalam upaya pelestarian. Blog ini mengajak pembaca untuk terlibat dan mendukung inisiatif-inisiatif konservasi, serta menyebarkan pengetahuan tentang bagaimana kita semua dapat berperan dalam melindungi keanekaragaman hayati yang tak ternilai harganya.', '1723743257blog48.jpg', '2024-08-15 17:34:17', 9, 27, 0),
(16, 'Musik sebagai Terapi: Harmoni untuk Kesejahteraan', 'Musik memiliki kekuatan penyembuhan yang luar biasa, yang sering kali diabaikan dalam kehidupan sehari-hari. Dalam blog ini, kami menjelajahi bagaimana musik digunakan sebagai bentuk terapi untuk meningkatkan kesehatan mental dan fisik. Dari teknik-teknik musik terapi yang diterapkan dalam berbagai setting medis hingga dampaknya pada kondisi psikologis, Anda akan menemukan bagaimana melodi dan ritme dapat mempengaruhi kesejahteraan kita.\r\n\r\nKami menyajikan berbagai contoh nyata dari kehidupan orang-orang yang telah merasakan manfaat terapi musik. Dengan menampilkan kisah-kisah inspiratif dan studi kasus, blog ini menunjukkan bagaimana musik dapat membantu mengatasi berbagai tantangan kesehatan, seperti stres, kecemasan, dan pemulihan pasca-trauma. Temukan bagaimana terapi musik memberikan dampak positif yang signifikan pada kualitas hidup banyak orang.\r\n\r\nMelalui eksplorasi mendalam ini, Anda akan memahami lebih jauh tentang kekuatan penyembuhan musik dan bagaimana Anda dapat memanfaatkan manfaatnya dalam kehidupan sehari-hari. Blog ini bertujuan untuk menginspirasi pembaca untuk mengeksplorasi dan menerapkan terapi musik sebagai alat untuk meningkatkan kesejahteraan pribadi dan emosional.', '1723743281blog49.jpg', '2024-08-15 17:34:41', 13, 27, 0),
(18, 'Menggali Jejak Masa Lalu', 'Sejarah adalah cermin yang merefleksikan perjalanan umat manusia dari masa ke masa, dan dalam blog ini, kami menyajikan tinjauan mendalam tentang peristiwa-peristiwa penting yang membentuk dunia modern. Dari kebangkitan peradaban kuno yang menyusun fondasi peradaban manusia, hingga revolusi industri yang mengubah struktur sosial dan ekonomi secara dramatis, setiap momen sejarah memiliki pengaruh besar terhadap perkembangan zaman. Memahami perjalanan ini memberi kita gambaran yang lebih jelas tentang bagaimana kita sampai pada titik ini.\r\n\r\nBlog ini mengeksplorasi dampak peristiwa-peristiwa bersejarah terhadap masyarakat saat ini, menggali bagaimana keputusan dan tindakan di masa lalu membentuk kondisi dan tantangan yang kita hadapi sekarang. Dengan menelusuri jejak sejarah, kita bisa melihat pola-pola dan tren yang mengulangi diri dalam berbagai konteks, menawarkan wawasan yang berguna untuk menyikapi isu-isu kontemporer. Analisis ini membantu kita memahami lebih dalam tentang dinamika sosial, politik, dan ekonomi yang terus berkembang.\r\n\r\nDengan mempelajari sejarah, kita tidak hanya mendapatkan perspektif tentang masa lalu, tetapi juga pelajaran berharga untuk membangun masa depan yang lebih baik. Setiap bab sejarah membawa pengetahuan yang bisa diterapkan untuk memperbaiki kesalahan dan menginspirasi inovasi. Blog ini mengajak pembaca untuk merenung dan belajar dari sejarah sebagai cara untuk menciptakan perubahan positif di masa depan.', '1723746244blog10.jpg', '2024-08-15 18:24:04', 17, 3, 1),
(19, 'Panduan Hidup Sehat dan Seimbang', 'Kesehatan bukan hanya tentang kebugaran fisik, tetapi juga melibatkan kesejahteraan mental dan emosional yang holistik. Blog ini menyajikan panduan lengkap tentang gaya hidup sehat, dengan fokus pada berbagai aspek yang mempengaruhi keseimbangan hidup kita. Dari nutrisi yang tepat hingga rutinitas olahraga yang bermanfaat, serta teknik meditasi dan relaksasi yang dapat menenangkan pikiran, kami menawarkan informasi yang dapat membantu Anda mencapai kesehatan optimal.\r\n\r\nKami mengeksplorasi berbagai strategi dan kebiasaan yang dapat diterapkan dalam kehidupan sehari-hari untuk meningkatkan kualitas hidup secara keseluruhan. Dengan menyadari pentingnya keseimbangan antara tubuh dan pikiran, Anda akan belajar bagaimana cara merawat diri dengan cara yang holistik. Blog ini memberikan tips praktis yang dapat membantu Anda mengatasi stres, meningkatkan energi, dan mencapai kebahagiaan jangka panjang.\r\n\r\nPelajari bagaimana kebiasaan kecil yang konsisten dapat membawa perubahan besar dalam kesehatan dan kesejahteraan Anda. Kami membagikan wawasan tentang bagaimana mengintegrasikan praktik-praktik sehat dalam rutinitas harian Anda, sehingga Anda dapat menikmati manfaat kesehatan yang berkelanjutan dan hidup dengan lebih seimbang. Temukan cara-cara sederhana namun efektif untuk merawat diri dan menciptakan gaya hidup yang mendukung kebahagiaan dan kesehatan jangka panjang.', '1723746348blog6.jpg', '2024-08-15 18:25:48', 16, 24, 0),
(20, 'Menyelami Pemikiran dan Refleksi', 'Filsafat adalah pencarian tanpa akhir akan makna dan kebenaran, sebuah perjalanan intelektual yang mendorong kita untuk mempertanyakan dan memahami dunia dengan lebih mendalam. Dalam blog ini, kami mengajak Anda untuk menjelajahi berbagai konsep fundamental seperti etika, eksistensi, dan kesadaran, yang telah menjadi subjek perdebatan para pemikir terbesar sepanjang sejarah. Dengan menggali ide-ide ini, kita bisa mulai meresapi inti dari berbagai pandangan filosofis yang membentuk pemikiran manusia.\r\n\r\nBlog ini mengulas berbagai aliran dan pemikiran filsafat yang telah menginspirasi refleksi mendalam tentang kehidupan dan realitas. Dari pemikiran Plato dan Aristoteles hingga Nietzsche dan Sartre, kami mengeksplorasi bagaimana ide-ide ini telah mempengaruhi cara kita melihat diri kita sendiri dan dunia di sekitar kita. Dengan memahami berbagai perspektif filosofis, kita dapat menantang dan memperluas pandangan kita tentang apa itu realitas dan bagaimana kita harus menjalani hidup.\r\n\r\nDengan meneliti filsafat, kita tidak hanya mendapatkan wawasan tentang pemikiran historis, tetapi juga alat untuk refleksi pribadi dan perkembangan diri. Blog ini bertujuan untuk membantu Anda menemukan makna dan pemahaman yang lebih dalam, serta mengajak Anda untuk mempertanyakan asumsi dan pandangan yang ada. Temukan bagaimana filsafat dapat memperkaya kehidupan Anda dan menawarkan cara baru untuk memahami eksistensi dan moralitas.\r\n\r\n', '1723746432blog4.jpg', '2024-08-15 18:27:12', 7, 28, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(225) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `is_admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `email`, `password`, `avatar`, `is_admin`) VALUES
(3, 'Richard', 'Ransun', 'Richard', 'richard@gmail.com', '$2y$10$vbKHbLSPOrW5f.jFlWDzVeW3bR0iKchBApayjoLfJT6xQX5YSJzei', '1723634342avatar3.jpg', 1),
(24, 'Jophi', 'Ransun', 'Jophi', 'jophi@gmail.com', '$2y$10$rOvW8CDDCT3bTKlXzMyBqu.ANoj9Gx94ELkkxG2eubuYzPKTK8Z3G', '1723711421avatar8.jpg', 0),
(26, 'Andew Robert', 'Junior', 'Andrew', 'andrew@gmail.com', '$2y$10$buf2mN2tHTU66G3Yu1ftGuiLSlsEj.pzPLTvT6CvWeKpzlOt9pe7G', '1723742445avatar15.jpg', 0),
(27, 'Florietta', 'Sabrina', 'Florietta', 'Flo@gmail.com', '$2y$10$ZG1plAAHTr1miaKW5zLCdOE/5hDqelWXrM61EaHj/xldr6C3j/C4O', '1723742479avatar7.jpg', 0),
(28, 'Wulan', 'Runsun', 'Wulan', 'wulan@gmail.com', '$2y$10$FBACq4kQdByVnhPlcYLWSOpx3T1VJHoUAhsM/bCZoCAUatxAMSDP6', '1723742514avatar5.jpg', 0);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_myblogs_category` (`category_id`),
  ADD KEY `FK_myblogs_author` (`author_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `FK_myblogs_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_myblogs_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
